import { and, count, desc, eq, gte, isNotNull, or } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import type { ArticleInput } from "../shared/articles";
import { articleImages, articles, articleTags, categories, images, tags, tipTopics, type ArticleRecord } from "../drizzle/schema";
import { getDb } from "./db";
import type { ProcessedCover } from "./agentImages";

type ArticleDb = NonNullable<Awaited<ReturnType<typeof getDb>>>;
function requireDb(db: ArticleDb | null | undefined): ArticleDb { if (!db) throw new Error("A base de dados não está configurada"); return db; }
function configuredAuthorId(): number { const id = Number(process.env.AGENT_AUTHOR_ID ?? ""); if (!Number.isInteger(id) || id <= 0) throw new Error("AGENT_AUTHOR_ID inválido"); return id; }

async function lookupId(tx: any, table: typeof categories | typeof tipTopics, slug: string, label: string) {
  const rows = await tx.select({ id: table.id }).from(table).where(eq(table.slug, slug)).limit(1);
  if (!rows[0]) throw new Error(`${label} não encontrada: ${slug}`);
  return rows[0].id;
}

export async function insertArticle(input: ArticleInput & { slug: string }, cover: ProcessedCover, agent: { topicSlug: string; idempotencyKey: string; requestHash: string }) {
  const db = requireDb(await getDb());
  const now = new Date();
  return db.transaction(async (tx) => {
    const categoryId = input.categorySlug ? await lookupId(tx, categories, input.categorySlug, "Categoria") : null;
    const tipTopicId = input.tipTopic ? await lookupId(tx, tipTopics, input.tipTopic, "Tema"): null;
    const [row] = await tx.insert(articles).values({
      contentType: input.type, slug: input.slug, title: input.title, excerpt: input.excerpt,
      categorySlug: input.categorySlug ?? null, tipTopicId, authorId: configuredAuthorId(), bodyMd: input.bodyMd,
      structured: input.structured ?? null, sources: input.sources, relatedTopics: input.relatedTopics,
      status: input.status ?? "draft", reviewStatus: "pending", publishedAt: input.status === "published" ? now : null,
      aiModel: input.aiModel, generationMeta: input.generationMeta, agentTopicSlug: agent.topicSlug,
      agentIdempotencyKey: agent.idempotencyKey, agentRequestHash: agent.requestHash, updatedAt: now,
    }).returning();
    const imageId = randomUUID();
    await tx.insert(images).values({ id: imageId });
    await tx.insert(articleImages).values({ articleId: row.id, imageId, imageUrl: cover.url });
    if (input.tags.length) {
      const tagRows = await tx.select({ id: tags.id }).from(tags).where(or(...input.tags.map((tag) => eq(tags.slug, tag))));
      if (tagRows.length !== input.tags.length) throw new Error("Uma ou mais tags não foram encontradas");
      await tx.insert(articleTags).values(tagRows.map((tag) => ({ articleId: row.id, tagId: tag.id })));
    }
    return { ...row, coverImageUrl: cover.url, coverImageAlt: input.coverImageAlt, coverImageVariants: cover.variants, coverImageSource: cover.source, coverImageIsAi: cover.isAi, categoryId };
  });
}

export async function listPublishedArticles(limit = 24) {
  const db = requireDb(await getDb());
  return db.select({ id: articles.id, type: articles.contentType, slug: articles.slug, title: articles.title, excerpt: articles.excerpt,
    tipTopic: tipTopics.slug, coverImageUrl: articleImages.imageUrl, coverImageAlt: articles.title, coverImageVariants: {},
    status: articles.status, publishedAt: articles.publishedAt, updatedAt: articles.updatedAt }).from(articles)
    .leftJoin(tipTopics, eq(articles.tipTopicId, tipTopics.id)).leftJoin(articleImages, eq(articles.id, articleImages.articleId))
    .where(and(eq(articles.status, "published"), isNotNull(articles.publishedAt))).orderBy(desc(articles.publishedAt), desc(articles.id)).limit(limit);
}
export async function getPublishedArticleSlugs() { const db = requireDb(await getDb()); return db.select({ slug: articles.slug, updatedAt: articles.updatedAt }).from(articles).where(and(eq(articles.status, "published"), isNotNull(articles.publishedAt))).orderBy(desc(articles.publishedAt)); }
export async function getPublishedArticleBySlug(slug: string): Promise<ArticleRecord | null> {
  const db = requireDb(await getDb());
  const rows = await db.select({ article: articles, coverImageUrl: articleImages.imageUrl }).from(articles)
    .leftJoin(articleImages, eq(articles.id, articleImages.articleId))
    .where(and(eq(articles.slug, slug), eq(articles.status, "published"))).limit(1);
  if (!rows[0]) return null;
  return { ...rows[0].article, coverImageUrl: rows[0].coverImageUrl ?? "", coverImageAlt: rows[0].article.title,
    coverImageVariants: {}, coverImageSource: null, coverImageIsAi: false } as ArticleRecord;
}
export async function getArticleByIdempotencyKey(key: string): Promise<ArticleRecord | null> { const db = requireDb(await getDb()); const rows = await db.select().from(articles).where(eq(articles.agentIdempotencyKey, key)).limit(1); return (rows[0] as ArticleRecord | undefined) ?? null; }
export async function getArticleByTopicSlug(topicSlug: string): Promise<ArticleRecord | null> { const db = requireDb(await getDb()); const rows = await db.select().from(articles).where(eq(articles.agentTopicSlug, topicSlug)).limit(1); return (rows[0] as ArticleRecord | undefined) ?? null; }
export const getAgentArticleByTopicSlug = getArticleByTopicSlug;
export async function countPublishedTipsSince(since: Date): Promise<number> { const db = requireDb(await getDb()); const rows = await db.select({ value: count() }).from(articles).where(and(eq(articles.contentType, "tip"), eq(articles.status, "published"), gte(articles.publishedAt, since))); return Number(rows[0]?.value ?? 0); }
export async function countAgentArticlesSince(status: "draft" | "published", since: Date): Promise<number> { const db = requireDb(await getDb()); const timestamp = status === "draft" ? articles.createdAt : articles.publishedAt; const rows = await db.select({ value: count() }).from(articles).where(and(eq(articles.status, status), gte(timestamp, since))); return Number(rows[0]?.value ?? 0); }
