import { describe, expect, it } from "vitest";
import { articleInputSchema } from "./articles";

const base = {
  type: "tip" as const,
  title: "Como temperar chocolate em casa",
  excerpt: "Uma orientação prática para obter brilho, textura e acabamento consistentes.",
  tipTopic: "preparo",
  bodyMd: "x".repeat(200),
  sources: [],
  tags: ["temperagem"],
  relatedTopics: [],
  cover: { mode: "generate" as const, imagePrompt: "Chocolate temperado" },
  coverImageAlt: "Chocolate temperado em uma bancada",
  aiModel: "test-model",
  generationMeta: { run_id: "run-1", topic_slug: "preparo" },
};

describe("articleInputSchema", () => {
  it("aceita dica e usa draft como status padrão", () => {
    const result = articleInputSchema.parse(base);
    expect(result.status).toBe("draft");
  });

  it("rejeita tópico ausente, tags repetidas e categoria desconhecida no formato", () => {
    const result = articleInputSchema.safeParse({ ...base, tipTopic: undefined, tags: ["x", "x"], categorySlug: "Categoria inválida" });
    expect(result.success).toBe(false);
    if (!result.success) expect(result.error.issues.map((issue) => issue.path.join("."))).toEqual(expect.arrayContaining(["tipTopic", "tags", "categorySlug"]));
  });

  it("exige categoria e fontes para conteúdo que não é dica", () => {
    const result = articleInputSchema.safeParse({ ...base, type: "feature", tipTopic: undefined });
    expect(result.success).toBe(false);
    if (!result.success) expect(result.error.issues.map((issue) => issue.path.join("."))).toEqual(expect.arrayContaining(["categorySlug", "sources"]));
  });
});
