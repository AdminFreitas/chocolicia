import { foreignKey, index, integer, jsonb, pgEnum, pgTable, primaryKey, serial, text, timestamp, uniqueIndex, uuid, varchar } from "drizzle-orm/pg-core";
import type { RecipeInput } from "../shared/recipes";
import type { ArticleInput } from "../shared/articles";

export const userRole = pgEnum("user_role", ["user", "admin"]);
export const recipeStatus = pgEnum("recipe_status", ["draft", "published", "failed"]);

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  openId: varchar("open_id", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("login_method", { length: 64 }),
  role: userRole("role").default("user").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  lastSignedIn: timestamp("last_signed_in", { withTimezone: true }).defaultNow().notNull(),
});

export const s3Files = pgTable("s3_files", {
  id: serial("id").primaryKey(),
  objectKey: text("object_key").notNull().unique(),
  fileUrl: text("file_url").notNull(),
  alt: varchar("alt", { length: 180 }).notNull(),
  contentType: varchar("content_type", { length: 255 }),
  userId: varchar("user_id", { length: 128 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  eventType: varchar("event_type", { length: 120 }).notNull(),
  guests: varchar("guests", { length: 80 }).notNull(),
  desiredDate: varchar("desired_date", { length: 32 }),
  category: varchar("category", { length: 120 }).notNull(),
  details: text("details"),
  status: varchar("status", { length: 32 }).default("new").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const recipes = pgTable("recipes", {
  id: uuid("id").defaultRandom().primaryKey(),
  slug: varchar("slug", { length: 180 }).notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  excerpt: varchar("excerpt", { length: 160 }).notNull(),
  category: varchar("category", { length: 80 }).notNull(),
  subcategory: varchar("subcategory", { length: 120 }),
  subcategorySlug: varchar("subcategory_slug", { length: 120 }),
  tags: text("tags").array().notNull().default([]),
  coverImageUrl: text("cover_image_url").notNull(),
  coverImageAlt: varchar("cover_image_alt", { length: 240 }).notNull(),
  imagePrompt: text("image_prompt").notNull().default(""),
  coverImageVariants: jsonb("cover_image_variants").$type<RecipeInput["coverImageVariants"]>().notNull().default({}),
  ingredients: jsonb("ingredients").$type<RecipeInput["ingredients"]>().notNull().default([]),
  steps: jsonb("steps").$type<RecipeInput["steps"]>().notNull().default([]),
  tips: jsonb("tips").$type<string[]>().notNull().default([]),
  storageNotes: text("storage_notes").notNull().default(""),
  faq: jsonb("faq").$type<RecipeInput["faq"]>().notNull().default([]),
  prepTimeMin: integer("prep_time_min").notNull(),
  cookTimeMin: integer("cook_time_min").notNull().default(0),
  servings: integer("servings").notNull(),
  difficulty: varchar("difficulty", { length: 24 }).notNull(),
  status: recipeStatus("status").notNull().default("draft"),
  publishedAt: timestamp("published_at", { withTimezone: true }),
  aiModel: varchar("ai_model", { length: 120 }),
  generationMeta: jsonb("generation_meta").$type<Record<string, unknown>>().notNull().default({}),
  agentTopicSlug: varchar("agent_topic_slug", { length: 180 }),
  agentIdempotencyKey: varchar("agent_idempotency_key", { length: 128 }),
  agentRequestHash: varchar("agent_request_hash", { length: 64 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => [
  uniqueIndex("recipes_slug_uidx").on(table.slug),
  uniqueIndex("recipes_agent_topic_slug_uidx").on(table.agentTopicSlug),
  uniqueIndex("recipes_agent_idempotency_key_uidx").on(table.agentIdempotencyKey),
  index("recipes_status_published_at_idx").on(table.status, table.publishedAt.desc()),
  index("recipes_category_idx").on(table.category),
  index("recipes_subcategory_slug_idx").on(table.subcategorySlug),
]);

export const categories = pgTable("categories", {
  id: integer("id").primaryKey(),
  slug: varchar("slug", { length: 180 }).notNull().unique(),
});

export const tipTopics = pgTable("tip_topics", {
  id: integer("id").primaryKey(),
  slug: varchar("slug", { length: 180 }).notNull().unique(),
});

export const tags = pgTable("tags", {
  id: integer("id").primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
});

export const images = pgTable("images", {
  id: uuid("id").primaryKey(),
});

export const articles = pgTable("articles", {
  id: uuid("id").defaultRandom().primaryKey(),
  contentType: varchar("content_type", { length: 32 }).notNull(),
  slug: varchar("slug", { length: 180 }).notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  excerpt: varchar("excerpt", { length: 160 }).notNull(),
  categorySlug: varchar("category_slug", { length: 180 }),
  tipTopicId: integer("tip_topic_id"),
  authorId: integer("author_id").notNull(),
  bodyMd: text("body_md").notNull(),
  structured: jsonb("structured").$type<Record<string, unknown>>(),
  sources: jsonb("sources").$type<ArticleInput["sources"]>().notNull().default([]),
  relatedTopics: jsonb("related_topics").$type<string[]>().notNull().default([]),
  status: varchar("status", { length: 32 }).notNull().default("draft"),
  reviewStatus: varchar("review_status", { length: 32 }).notNull().default("pending"),
  publishedAt: timestamp("published_at", { withTimezone: true }),
  aiModel: varchar("ai_model", { length: 120 }).notNull(),
  generationMeta: jsonb("generation_meta").$type<Record<string, unknown>>().notNull().default({}),
  agentTopicSlug: varchar("agent_topic_slug", { length: 180 }),
  agentIdempotencyKey: varchar("agent_idempotency_key", { length: 128 }),
  agentRequestHash: varchar("agent_request_hash", { length: 64 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => [
  foreignKey({ columns: [table.authorId], foreignColumns: [users.id], name: "articles_author_id_fkey" }),
  foreignKey({ columns: [table.tipTopicId], foreignColumns: [tipTopics.id], name: "articles_tip_topic_id_fkey" }),
  uniqueIndex("articles_slug_uidx").on(table.slug),
  uniqueIndex("articles_agent_topic_slug_uidx").on(table.agentTopicSlug),
  uniqueIndex("articles_agent_idempotency_key_uidx").on(table.agentIdempotencyKey),
  index("articles_status_published_at_idx").on(table.status, table.publishedAt.desc()),
  index("articles_tip_topic_idx").on(table.tipTopicId),
]);

export const articleTags = pgTable("article_tags", {
  articleId: uuid("article_id").notNull(),
  tagId: integer("tag_id").notNull(),
}, (table) => [
  primaryKey({ columns: [table.articleId, table.tagId] }),
  foreignKey({ columns: [table.articleId], foreignColumns: [articles.id], name: "article_tags_article_id_fkey" }),
  foreignKey({ columns: [table.tagId], foreignColumns: [tags.id], name: "article_tags_tag_id_fkey" }),
]);

export const articleImages = pgTable("article_images", {
  articleId: uuid("article_id").notNull(),
  imageId: uuid("image_id").notNull(),
  imageUrl: text("image_url").notNull(),
}, (table) => [
  primaryKey({ columns: [table.articleId, table.imageId] }),
  foreignKey({ columns: [table.articleId], foreignColumns: [articles.id], name: "article_images_article_id_fkey" }),
  foreignKey({ columns: [table.imageId], foreignColumns: [images.id], name: "article_images_image_id_fkey" }),
]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type S3File = typeof s3Files.$inferSelect;
export type InsertS3File = typeof s3Files.$inferInsert;
export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;
export type Recipe = typeof recipes.$inferSelect;
export type InsertRecipe = typeof recipes.$inferInsert;
export type ArticleRecord = typeof articles.$inferSelect & {
  coverImageUrl: string;
  coverImageAlt: string;
  coverImageVariants: Record<string, string>;
  coverImageSource: Record<string, unknown> | null;
  coverImageIsAi: boolean;
};
export type InsertArticle = typeof articles.$inferInsert;
